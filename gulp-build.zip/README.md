#### Prepare
`npm install`
`npm install -g gulp`

#### Start Dev Server
`gulp dev`

#### Production Build
`gulp build`

#### Deploy built version
`./deploy-ghpages.sh`